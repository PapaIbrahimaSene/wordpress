=== AutoDeal ===
Tags: bootstrap, simple, 2-column, 3-column, responsive, mobile-ready


Wordpress Theme
== Description ==

Automotive Industry Wordpress Theme

Installation

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in AutoDeal in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.


== Resources ==

AutoDeal WordPress Theme, Copyright 2018 ThemesPride
