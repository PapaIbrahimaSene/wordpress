=== Post Signature ===
Contributors: insertpostsignature
Tags: Content Injection injection
Requires at least: 3.6
Tested up to: 5.0.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically insert content after paragraphs of your posts, pages, and custom post types.

== Description ==

= Ads Plugin With Auto Ad Injection =

Automatically insert content after paragraphs of your posts, pages, and custom post types.

= Post Signature Features =

Automatically insert content after paragraphs of your posts, pages, and custom post types.

Post Signature makes monetizing your blog easy.

== Installation ==

Automatically insert content after paragraphs of your posts, pages, and custom post types.

== Screenshots ==

1. Screenshot1
2. Screenshot2

== Frequently Asked Questions ==

= FAQ1? =

Faq

== Notes ==

Post Signature is an injection plugin


== Changelog ==
= 1.0.0 =
* 1.0.0

= 1.3
* First release

== Privacy Policy ==
